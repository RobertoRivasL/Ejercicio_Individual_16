import java.util.Scanner;

public class ValidarClave {

    public static void main(String[] args) {
        //Definir la clave
        Scanner leer = new Scanner(System.in);
        String clave = "123456";
        int intentos = 0;

        for (int i = 0; i < 3; i++){
            System.out.println("Escribir contraseña");
            String var = leer.nextLine();
            if(var.equals(clave)) {
                System.out.println("Contraseña correcta");
                System.out.println("Bienvenido al Sistema");
                break;
            }
            else  {
                System.out.println("Contraseña incorrecta");
                intentos = intentos + 1;
                System.out.println("Numero de intento: "+intentos);

            }
            if (intentos==3){
                System.out.println("Numero de intentos finalizados");
                break;
            }
        }
    }

}
